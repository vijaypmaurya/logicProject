﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using ProofOfConcept.Data.Entity;
using ProofOfConcept.Model.Model;

namespace ProofOfConcept.Data.Helper  
{
     public class AutoMapperProfiles : Profile
{
    public AutoMapperProfiles()
    {
        CreateMap<User, UserModel>();
    }
}
}
