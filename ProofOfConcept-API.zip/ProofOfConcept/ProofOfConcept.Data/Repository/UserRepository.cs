﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using ProofOfConcept.Data.Context;
using ProofOfConcept.Data.Entity;
using ProofOfConcept.Model.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;

namespace ProofOfConcept.Data.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly DataContext _context;
        private readonly IMapper _mapper;

        public UserRepository(DataContext context, IMapper mapper)
        {
            _mapper = mapper;
            _context = context;
        }

        public async Task<UserModel> GetUser(string email)
        {
            return await _context.Users
               .Where(x => x.Email == email)
               .ProjectTo<UserModel>(_mapper.ConfigurationProvider)
               .FirstOrDefaultAsync();
        }
        public async Task<User> AddUser(User user)
        {
            _context.Users.Add(user);
            await _context.SaveChangesAsync();
            return user;
        }
        public async Task<User> UpdateUser(User user)
        {
           var result= _context.Users.Where(x=>x.UserId==user.UserId).FirstOrDefault();
            if (result != null)
            {
                result.FullName = user.FullName;
                result.Phone = user.Phone;
                result.Email = user.Email;
                result.Age = user.Age;
                await _context.SaveChangesAsync();
                return user;
            }
          
            return null;
        }
        public async Task<User> DeleteUser(int Id)
        {
           
            var user = _context.Users.FirstOrDefault(u => u.UserId == Id);
            if (user != null)
            {
                _context.Users.Remove(user);
                await _context.SaveChangesAsync();
                return user;
            }
            return null;
        }
        public async Task<IEnumerable<User>> SearchUser(string email, string phone, string sort)
        {           
            var query = _context.Users.AsQueryable();

            if (!string.IsNullOrEmpty(email))
            {                
                query = query.Where(x => x.Email.Contains(email));
            }
            if (!string.IsNullOrEmpty(phone))
            {               
                query = query.Where(x => x.Phone.Contains(phone));
            }

            if (!string.IsNullOrEmpty(sort) && sort.ToLower() == "fullname")
            {
                query = query.OrderBy(x => x.FullName);
            }
            if (!string.IsNullOrEmpty(sort) && sort.ToLower() == "email")
            {
                query = query.OrderBy(x => x.Email);
            }
            if (!string.IsNullOrEmpty(sort) && sort.ToLower() == "phone")
            {
                query = query.OrderBy(x => x.Phone);
            }
            if (!string.IsNullOrEmpty(sort) && sort.ToLower() == "age")
            {
                query = query.OrderBy(x => x.Age);
            }
            return await query.ToListAsync();         
        }

    }
}
