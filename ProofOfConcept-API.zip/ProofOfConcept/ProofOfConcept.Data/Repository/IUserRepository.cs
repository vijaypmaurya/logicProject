﻿using ProofOfConcept.Data.Entity;
using ProofOfConcept.Model.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProofOfConcept.Data.Repository
{
    public interface IUserRepository
    {
        Task<UserModel> GetUser(string email);
        Task<User> AddUser(User user);
        Task<User> UpdateUser(User user);
        Task<User> DeleteUser(int Id);
        Task<IEnumerable<User>> SearchUser(string email, string phone, string sort);
    }
}
