﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProofOfConcept.Data.Entity;
using ProofOfConcept.Data.Repository;
using ProofOfConcept.Model.Model;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace ProofOfConcept.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IMapper _mapper;
        private readonly IUnitOfWork _unitOfWork;
        public UserController(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
        /// <summary>
        /// This method is use to add new user in Db
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPost("AddUsers")]
        public async Task<ActionResult<UserModel>> AddUser(User user)
        {
            if (await UserExists(user.Email)) return BadRequest("User with this email already exists");
            var result = await _unitOfWork.UserRepository.AddUser(user);
            if (result == null) return BadRequest("Unable to Create User");
            return Ok(result.UserId);
        }
        /// <summary>
        /// this method is use to update user's information .
        /// </summary>
        /// <param name="user"></param>
        /// <returns></returns>
        [HttpPut("UpdateUser")]
        public async Task<ActionResult<UserModel>> UpdateUser(User user)
        {            
            if (user.FullName != null && user.UserId!=0)
            {
                var result = await _unitOfWork.UserRepository.UpdateUser(user);
                if (result == null) return BadRequest("Unable to Create User ");
            }
            return Ok("User Updated Successfully");
        }
        /// <summary>
        /// this method is use to delete a user .
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        [HttpDelete("DeleteUser")]
        public async Task<ActionResult<UserModel>> DeleteUser(int Id)
        {            
            if (Id != 0)
            {
                var result = await _unitOfWork.UserRepository.DeleteUser(Id);
                if (result == null) return BadRequest("Unable to Create User ");
            }
            return Ok("User Deleted Successfully");
        }
        /// <summary>
        /// this method is use to search  and sort user from the Db
        /// </summary>
        /// <param name="email"></param>
        /// <param name="phone"></param>
        /// <param name="sort"></param>
        /// <returns></returns>
        [HttpGet("SearchUser")]
        public async Task<ActionResult<User>> SearchUser(string? email,string? phone,string? sort)
        {            
            if (!string.IsNullOrEmpty(email) || (!string.IsNullOrEmpty(phone)))
            {
                var result =  await _unitOfWork.UserRepository.SearchUser(email,phone,sort);
                if (result == null || !result.Any()) return BadRequest("No search user found");
                return Ok(result);
            }
            return BadRequest("Please search for email or phone");
        }
        /// <summary>
        /// this method is use to check username is available or not .
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        private async Task<bool> UserExists(string username)
        {
            var users = await _unitOfWork.UserRepository.GetUser(username);
            if (users != null)
                return true;
            else
                return false;
        }
    }
}
